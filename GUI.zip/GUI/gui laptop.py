from pathlib import Path
from tkinter import *
from PIL import Image, ImageTk
import cv2
import os

vid = cv2.VideoCapture(0) 

OUTPUT_PATH = Path(__file__).parent
a = os.getcwd()
ASSETS_PATH = OUTPUT_PATH / Path(r"{}\assets\frame0".format(a))


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

window = Tk()

window.geometry("1100x857")

canvas = Canvas(
    window,
    bg = "#363636",
    height = 857,
    width = 1100,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
window.bind('<Escape>', lambda e: window.quit()) 

label_widget = Label(window) 
label_widget.place(x = 24, y = 119, width = 640, height = 480) 

def open_camera(): 
    ret, frame = vid.read()
    opencv_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) 
    captured_image = Image.fromarray(opencv_image)  
    photo_image = ImageTk.PhotoImage(image=captured_image) 
    label_widget.photo_image = photo_image 
    label_widget.configure(image=photo_image)
    label_widget.after(1, open_camera)

image_image_1 = PhotoImage(
    file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(
    886.0,
    133.0,
    image=image_image_1
)

button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=open_camera,
    relief="flat"
)
button_1.place(
    x=752.0,
    y=490.0,
    width=270.0,
    height=58.0
)

image_image_2 = PhotoImage(
    file=relative_to_assets("image_2.png"))
image_2 = canvas.create_image(
    887.0,
    588.0,
    image=image_image_2
)

image_image_3 = PhotoImage(
    file=relative_to_assets("image_3.png"))
image_3 = canvas.create_image(
    887.0,
    324.0,
    image=image_image_3
)

image_image_4 = PhotoImage(
    file=relative_to_assets("image_4.png"))
image_4 = canvas.create_image(
    550.0,
    739.0,
    image=image_image_4
)

image_image_5 = PhotoImage(
    file=relative_to_assets("image_5.png"))
image_5 = canvas.create_image(
    550.0,
    62.0,
    image=image_image_5
)
window.resizable(False, False)
window.mainloop()
